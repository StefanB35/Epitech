"""
Test_Prediction_ID.py - Exemple d'utilisation de la prédiction par ID client

DESCRIPTION:
    Script d'exemple montrant comment utiliser les fonctions de prédiction
    avec les vrais IDs clients du dataset Clean_Camp_Market_with_clusters.csv

USAGE:
    python Test_Prediction_ID.py

AUTEUR: GitHub Copilot
DATE: 2025
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import sys
import os

# Importer les fonctions du script principal
sys.path.append('Rush 4/Clusturing')

def main():
    """
    Fonction principale de démonstration
    """
    print("=" * 70)
    print("🆔 TEST DE PRÉDICTION AVEC IDS CLIENTS RÉELS")
    print("=" * 70)
    
    # Charger les données
    data_path = 'Rush 4/Cleaned_data/Clean_Camp_Market_with_clusters.csv'
    
    if not os.path.exists(data_path):
        print(f"❌ Fichier non trouvé: {data_path}")
        return
    
    df = pd.read_csv(data_path)
    print(f"📂 Données chargées: {len(df)} clients")
    
    # Afficher quelques IDs d'exemple
    print(f"\n🔢 Exemples d'IDs clients disponibles:")
    sample_ids = df['ID'].head(10).tolist()
    for i, customer_id in enumerate(sample_ids, 1):
        print(f"   {i:2d}. Client ID: {customer_id}")
    
    # Vérifier la distribution de la variable Response
    response_dist = df['Response'].value_counts()
    print(f"\n📊 Distribution des réponses aux campagnes:")
    print(f"   Refus (0): {response_dist.get(0, 0)} clients ({response_dist.get(0, 0)/len(df)*100:.1f}%)")
    print(f"   Acceptation (1): {response_dist.get(1, 0)} clients ({response_dist.get(1, 0)/len(df)*100:.1f}%)")
    
    # Entraînement rapide d'un modèle pour la démonstration
    print(f"\n🤖 Entraînement rapide du modèle pour démonstration...")
    
    # Créer des features simplifiées
    df['Age'] = 2025 - df['Year_Birth']
    df['Total_Spending'] = (df['MntWines'] + df['MntFruits'] + df['MntMeatProducts'] + 
                           df['MntFishProducts'] + df['MntSweetProducts'] + df['MntGoldProds'])
    df['Total_Purchases'] = (df['NumDealsPurchases'] + df['NumWebPurchases'] + 
                            df['NumCatalogPurchases'] + df['NumStorePurchases'])
    
    # Sélectionner les features
    feature_cols = [
        'Age', 'Income', 'Recency', 'Total_Spending', 'Total_Purchases',
        'Kidhome', 'Teenhome', 'NumWebVisitsMonth', 'Education', 'Marital_Status', 'Cluster'
    ]
    
    X = df[feature_cols].copy()
    y = df['Response'].copy()
    customer_ids = df['ID'].copy()
    
    # Encoder les variables catégorielles
    X['Education'] = X['Education'].astype('category').cat.codes
    X['Marital_Status'] = X['Marital_Status'].astype('category').cat.codes
    X = X.fillna(X.median())
    
    # Diviser en train/test en conservant les IDs
    X_train, X_test, y_train, y_test, ids_train, ids_test = train_test_split(
        X, y, customer_ids, test_size=0.2, random_state=42, stratify=y
    )
    
    # Normaliser
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Entraîner le modèle
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    accuracy = model.score(X_test_scaled, y_test)
    print(f"   ✅ Modèle entraîné avec précision: {accuracy:.1%}")
    
    # Faire des prédictions sur quelques clients du set de test
    print(f"\n🔮 Prédictions sur des clients spécifiques (set de test):")
    print("="*60)
    
    # Prendre 5 clients du set de test
    test_sample = list(ids_test.head(5))
    
    for i, customer_id in enumerate(test_sample, 1):
        # Trouver l'index dans le test set
        test_idx = list(ids_test).index(customer_id)
        
        # Prédiction
        customer_scaled = X_test_scaled[test_idx:test_idx+1]
        prediction = model.predict(customer_scaled)[0]
        probability = model.predict_proba(customer_scaled)[0][1]
        
        # Vraie valeur
        true_value = list(y_test)[test_idx]
        
        # Informations du client
        customer_info = df[df['ID'] == customer_id].iloc[0]
        
        # Affichage
        status = "Acceptera" if prediction == 1 else "Refusera"
        true_status = "A accepté" if true_value == 1 else "A refusé"
        correct = "✅" if prediction == true_value else "❌"
        
        print(f"\n{i}. 🆔 CLIENT ID: {customer_id}")
        print(f"   👤 Âge: {2025 - customer_info['Year_Birth']} ans")
        print(f"   💰 Revenus: {customer_info['Income']:,.0f} €")
        print(f"   🛒 Dépenses totales: {customer_info['Total_Spending']:,.0f} €")
        print(f"   🎯 Cluster: {customer_info['Cluster']}")
        print(f"   🔮 Prédiction: {status} (Probabilité: {probability:.1%})")
        print(f"   ✅ Réalité: {true_status}")
        print(f"   {correct} Prédiction {'correcte' if prediction == true_value else 'incorrecte'}")
    
    # Statistiques globales des prédictions
    print(f"\n" + "="*60)
    print(f"📈 STATISTIQUES DU MODÈLE SUR LE SET DE TEST")
    print(f"="*60)
    
    y_pred_all = model.predict(X_test_scaled)
    y_proba_all = model.predict_proba(X_test_scaled)[:, 1]
    
    # Accuracy
    accuracy = (y_pred_all == y_test).mean()
    print(f"Précision globale: {accuracy:.1%}")
    
    # Prédictions par classe
    pred_accept = (y_pred_all == 1).sum()
    pred_refuse = (y_pred_all == 0).sum()
    print(f"Clients prédits pour accepter: {pred_accept}/{len(y_test)} ({pred_accept/len(y_test):.1%})")
    print(f"Clients prédits pour refuser: {pred_refuse}/{len(y_test)} ({pred_refuse/len(y_test):.1%})")
    
    # Sauvegarde des résultats avec IDs réels
    results_df = pd.DataFrame({
        'Customer_ID': list(ids_test),
        'True_Response': list(y_test),
        'Predicted_Response': y_pred_all,
        'Probability_Accept': y_proba_all
    })
    
    output_path = 'Rush 4/Cleaned_data/Test_Predictions_with_Real_IDs.csv'
    results_df.to_csv(output_path, index=False)
    print(f"\n💾 Résultats sauvegardés avec IDs réels: {output_path}")
    
    # Afficher un échantillon des résultats
    print(f"\n📋 Échantillon des résultats sauvegardés:")
    print(results_df.head().to_string(index=False))
    
    print(f"\n" + "="*70)
    print(f"✅ DÉMONSTRATION TERMINÉE - Les IDs clients réels sont préservés!")
    print(f"="*70)

if __name__ == "__main__":
    main()